export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>مرحبا بك في متجر واقد الإلكتروني</h1>
      <p>قريبًا سيتم عرض المنتجات والعروض هنا</p>
    </div>
  );
}